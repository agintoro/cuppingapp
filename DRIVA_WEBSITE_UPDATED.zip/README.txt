DRIVN / Driva Coffee Processing
Hostinger Node.js upload package

UPLOAD THIS PROJECT AS A ZIP TO HOSTINGER NODE.JS WEB APP.

Required Hostinger settings:
- Node version: 20.x
- Start command: npm start
- Entry file: server.js

Required environment variables:
OWNER_PIN=your-secret-pin
WHATSAPP_NUMBER=628xxxxxxxxxx
NODE_ENV=production

What was fixed in this version:
- Add/Edit lot saving bug fixed.
- API requests now keep Content-Type: application/json even when owner PIN header is sent.
- Backend now validates incoming lot data before saving.
- Backend creates a backup copy before overwriting data/lots.json.
- Backend returns clearer save/update/delete errors.

After upload, test:
1. https://yourdomain.com/api/health
2. https://yourdomain.com/api/lots
3. Try wrong owner PIN first. It must stay locked.
4. Try correct PIN, add one test lot, refresh, and confirm the lot remains.

Important:
Do not upload only dist.
Do not upload node_modules.
Do not put spaces in environment variables.
