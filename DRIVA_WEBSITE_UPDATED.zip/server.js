const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;
const OWNER_PIN = process.env.OWNER_PIN || '2468';
const WHATSAPP_NUMBER = process.env.WHATSAPP_NUMBER || '6280000000000';
const DATA_DIR = path.join(__dirname, 'data');
const LOTS_FILE = path.join(DATA_DIR, 'lots.json');
const PROCESSES_FILE = path.join(DATA_DIR, 'processes.json');
const DIST_DIR = path.join(__dirname, 'dist');

app.use(cors());
app.use(express.json({ limit: '2mb' }));

function ensureDataFiles() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(LOTS_FILE)) fs.writeFileSync(LOTS_FILE, '[]', 'utf8');
  if (!fs.existsSync(PROCESSES_FILE)) fs.writeFileSync(PROCESSES_FILE, '[]', 'utf8');
}

function readJson(file, fallback) {
  ensureDataFiles();
  try {
    const raw = fs.readFileSync(file, 'utf8').trim();
    if (!raw) return fallback;
    const parsed = JSON.parse(raw);
    return Array.isArray(fallback) && !Array.isArray(parsed) ? fallback : parsed;
  } catch (error) {
    console.error(`Failed to read JSON from ${file}:`, error.message);
    return fallback;
  }
}

function writeJson(file, data) {
  ensureDataFiles();
  const tmp = `${file}.tmp`;
  const backup = `${file}.bak`;
  const payload = JSON.stringify(data, null, 2);
  if (!payload || payload === 'undefined') throw new Error('Invalid JSON payload');
  if (fs.existsSync(file)) fs.copyFileSync(file, backup);
  fs.writeFileSync(tmp, payload, 'utf8');
  JSON.parse(fs.readFileSync(tmp, 'utf8'));
  fs.renameSync(tmp, file);
}

function makeSlug(text) {
  return String(text || '')
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '') || crypto.randomBytes(4).toString('hex');
}

function ownerAuthorized(req) {
  const token = req.headers['x-owner-pin'] || req.body?.ownerPin;
  return token && String(token) === String(OWNER_PIN);
}

app.get('/api/health', (req, res) => {
  res.json({ ok: true, app: 'DRIVN', node: process.version });
});

app.get('/api/settings', (req, res) => {
  res.json({ whatsappNumber: WHATSAPP_NUMBER });
});

app.post('/api/auth/owner', (req, res) => {
  const pin = req.body?.pin;
  if (String(pin) !== String(OWNER_PIN)) {
    return res.status(401).json({ error: 'Wrong PIN' });
  }
  res.json({ ok: true, message: 'Owner mode active' });
});

app.get('/api/lots', (req, res) => {
  const lots = readJson(LOTS_FILE, []);
  res.json(lots);
});

app.get('/api/lots/:slug', (req, res) => {
  const lots = readJson(LOTS_FILE, []);
  const lot = lots.find(item => item.slug === req.params.slug || item.id === req.params.slug);
  if (!lot) return res.status(404).json({ error: 'Lot not found' });
  res.json(lot);
});

app.post('/api/lots', (req, res) => {
  try {
    if (!ownerAuthorized(req)) return res.status(401).json({ error: 'Wrong PIN' });
    const lots = readJson(LOTS_FILE, []);
    const input = req.body?.lot || req.body;
    if (!input || typeof input !== 'object') return res.status(400).json({ error: 'Missing lot data' });
    const lotName = input.lotName || 'Untitled Lot';
  const id = input.id || crypto.randomUUID();
  const slug = input.slug || makeSlug(lotName);
  const now = new Date().toISOString();
  const lot = { ...input, id, slug, updatedAt: now, createdAt: input.createdAt || now };
  const existingIndex = lots.findIndex(item => item.id === id || item.slug === slug);
  if (existingIndex >= 0) lots[existingIndex] = { ...lots[existingIndex], ...lot };
  else lots.unshift(lot);
    writeJson(LOTS_FILE, lots);
    res.json({ ok: true, lot });
  } catch (error) {
    console.error('Failed to save lot:', error);
    res.status(500).json({ error: `Save failed: ${error.message}` });
  }
});

app.put('/api/lots/:id', (req, res) => {
  try {
    if (!ownerAuthorized(req)) return res.status(401).json({ error: 'Wrong PIN' });
    if (!req.body || typeof req.body !== 'object') return res.status(400).json({ error: 'Missing lot data' });
    const lots = readJson(LOTS_FILE, []);
    const index = lots.findIndex(item => item.id === req.params.id || item.slug === req.params.id);
    if (index < 0) return res.status(404).json({ error: 'Lot not found' });
    const updated = {
    ...lots[index],
    ...req.body,
    slug: req.body.slug || makeSlug(req.body.lotName || lots[index].lotName),
    updatedAt: new Date().toISOString()
  };
    lots[index] = updated;
    writeJson(LOTS_FILE, lots);
    res.json({ ok: true, lot: updated });
  } catch (error) {
    console.error('Failed to update lot:', error);
    res.status(500).json({ error: `Update failed: ${error.message}` });
  }
});

app.delete('/api/lots/:id', (req, res) => {
  try {
    if (!ownerAuthorized(req)) return res.status(401).json({ error: 'Wrong PIN' });
    const lots = readJson(LOTS_FILE, []);
    const filtered = lots.filter(item => item.id !== req.params.id && item.slug !== req.params.id);
    writeJson(LOTS_FILE, filtered);
    res.json({ ok: true, removed: lots.length - filtered.length });
  } catch (error) {
    console.error('Failed to delete lot:', error);
    res.status(500).json({ error: `Delete failed: ${error.message}` });
  }
});

app.get('/api/processes', (req, res) => {
  res.json(readJson(PROCESSES_FILE, []));
});

app.use(express.static(DIST_DIR));
app.get('*', (req, res) => {
  res.sendFile(path.join(DIST_DIR, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`DRIVN running on port ${PORT}`);
});
